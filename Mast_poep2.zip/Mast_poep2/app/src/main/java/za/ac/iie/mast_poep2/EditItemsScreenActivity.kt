package za.ac.iie.mast_poep2

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EditItemsScreenActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_items_screen)

        // Initialize UI components
        val itemNameEditText: EditText = findViewById(R.id.itemNameEditText)
        val itemDescriptionEditText: EditText = findViewById(R.id.itemDescriptionEditText)
        val itemPriceEditText: EditText = findViewById(R.id.itemPriceEditText)
        val courseSpinner: Spinner = findViewById(R.id.courseSpinner)
        val saveButton: Button = findViewById(R.id.saveButton)
        val removeButton: Button = findViewById(R.id.removeButton)
        val backButton: Button = findViewById(R.id.backButton)

        // Set up the course spinner
        val courses = arrayOf("Starters", "Main Courses", "Desserts")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, courses)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        courseSpinner.adapter = adapter

        // Saving the menu item
        saveButton.setOnClickListener {
            val itemName = itemNameEditText.text.toString()
            val itemDescription = itemDescriptionEditText.text.toString()
            val itemPrice = itemPriceEditText.text.toString().toDoubleOrNull()
            val selectedCourse = courseSpinner.selectedItem.toString()

            if (itemName.isNotBlank() && itemDescription.isNotBlank() && itemPrice != null) {
                // Save item (e.g., add it to a menu array or database)
                Toast.makeText(this, "$itemName added to $selectedCourse", Toast.LENGTH_SHORT).show()
                finish() // Go back to the home screen after saving
            } else {
                Toast.makeText(this, "Please fill in all fields correctly", Toast.LENGTH_SHORT).show()
            }
        }

        // Removing a menu item
        removeButton.setOnClickListener {
            // Implement the logic to remove the item
            Toast.makeText(this, "Item removed", Toast.LENGTH_SHORT).show()
        }

        // Going back to the previous screen
        backButton.setOnClickListener {
            finish()
        }
    }
}
