package za.ac.iie.mast_poep2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etUsername: EditText = findViewById(R.id.etUsername)
        val etPassword: EditText = findViewById(R.id.etPassword)
        val btnRegister: Button = findViewById(R.id.btnRegister)

        // Register button logic
        btnRegister.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                // Perform registration logic, e.g., save to database

                // Show success message
                Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()

                // Navigate to HomeScreenActivity after registration
                val intent = Intent(this, HomescreenActivity::class.java)
                startActivity(intent)

                // Optionally finish the RegisterActivity so the user can't go back to it
                finish()
            } else {
                Toast.makeText(this, "Please enter all details", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
